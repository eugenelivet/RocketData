#include "bmp280.h"

BMP280::BMP280(void)
{
    settings.I2CAddress = 0x76;
    settings.runMode = 0;
    settings.tempOverSample = 0;
    settings.pressOverSample = 0;
}

uint8_t BMP280::begin()
{
	uint8_t dataToWrite;
	delay(10);
    //Reading all compensation data, range 0x88:A1, 0xE1:E7
    calibration.dig_T1 = ((uint16_t)((readRegister(BMP280_DIG_T1_MSB_REG) << 8) + readRegister(BMP280_DIG_T1_LSB_REG)));
    calibration.dig_T2 = ((int16_t)((readRegister(BMP280_DIG_T2_MSB_REG) << 8) + readRegister(BMP280_DIG_T2_LSB_REG)));
    calibration.dig_T3 = ((int16_t)((readRegister(BMP280_DIG_T3_MSB_REG) << 8) + readRegister(BMP280_DIG_T3_LSB_REG)));
    calibration.dig_P1 = ((uint16_t)((readRegister(BMP280_DIG_P1_MSB_REG) << 8) + readRegister(BMP280_DIG_P1_LSB_REG)));
    calibration.dig_P2 = ((int16_t)((readRegister(BMP280_DIG_P2_MSB_REG) << 8) + readRegister(BMP280_DIG_P2_LSB_REG)));
    calibration.dig_P3 = ((int16_t)((readRegister(BMP280_DIG_P3_MSB_REG) << 8) + readRegister(BMP280_DIG_P3_LSB_REG)));
    calibration.dig_P4 = ((int16_t)((readRegister(BMP280_DIG_P4_MSB_REG) << 8) + readRegister(BMP280_DIG_P4_LSB_REG)));
    calibration.dig_P5 = ((int16_t)((readRegister(BMP280_DIG_P5_MSB_REG) << 8) + readRegister(BMP280_DIG_P5_LSB_REG)));
    calibration.dig_P6 = ((int16_t)((readRegister(BMP280_DIG_P6_MSB_REG) << 8) + readRegister(BMP280_DIG_P6_LSB_REG)));
    calibration.dig_P7 = ((int16_t)((readRegister(BMP280_DIG_P7_MSB_REG) << 8) + readRegister(BMP280_DIG_P7_LSB_REG)));
    calibration.dig_P8 = ((int16_t)((readRegister(BMP280_DIG_P8_MSB_REG) << 8) + readRegister(BMP280_DIG_P8_LSB_REG)));
    calibration.dig_P9 = ((int16_t)((readRegister(BMP280_DIG_P9_MSB_REG) << 8) + readRegister(BMP280_DIG_P9_LSB_REG)));
    //Set the oversampling control words.
    //config will only be writeable in sleep mode, so first insure that.
    writeRegister(BMP280_CTRL_MEAS_REG, 0x00);
    //Set the config word
    dataToWrite = (settings.tStandby << 0x5) & 0xE0;
    dataToWrite |= (settings.filter << 0x02) & 0x1C;
    writeRegister(BMP280_CONFIG_REG, dataToWrite);
    //set ctrl_meas
    //First, set temp oversampling
    dataToWrite = (settings.tempOverSample << 0x5) & 0xE0;
    //Next, pressure oversampling
    dataToWrite |= (settings.pressOverSample << 0x02) & 0x1C;
    //Last, set mode
    dataToWrite |= (settings.runMode) & 0x03;
    //Load the byte
    writeRegister(BMP280_CTRL_MEAS_REG, dataToWrite);
    return readRegister(BMP280_CHIP_ID_REG);
}

void BMP280::reset( void )
{
    writeRegister(BMP280_RST_REG, 0xB6);
}

float BMP280::readFloatPressure( void )
{
    // Returns pressure in Pa as unsigned 32 bit integer in Q24.8 format (24 integer bits and 8 fractional bits).
    // Output value of “24674867” represents 24674867/256 = 96386.2 Pa = 963.862 hPa
    int32_t adc_P = ((uint32_t)readRegister(BMP280_PRESSURE_MSB_REG) << 12) | ((uint32_t)readRegister(BMP280_PRESSURE_LSB_REG) << 4) | ((readRegister(BMP280_PRESSURE_XLSB_REG) >> 4) & 0x0F);
    int64_t var1, var2, p_acc;
    var1 = ((int64_t)t_fine) - 128000;
    var2 = var1 * var1 * (int64_t)calibration.dig_P6;
    var2 = var2 + ((var1 * (int64_t)calibration.dig_P5)<<17);
    var2 = var2 + (((int64_t)calibration.dig_P4)<<35);
    var1 = ((var1 * var1 * (int64_t)calibration.dig_P3)>>8) + ((var1 * (int64_t)calibration.dig_P2)<<12);
    var1 = (((((int64_t)1)<<47)+var1))*((int64_t)calibration.dig_P1)>>33;
    if (var1 == 0)
    {
        return 0; // avoid exception caused by division by zero
    }
    p_acc = 1048576 - adc_P;
    p_acc = (((p_acc<<31) - var2)*3125)/var1;
    var1 = (((int64_t)calibration.dig_P9) * (p_acc>>13) * (p_acc>>13)) >> 25;
    var2 = (((int64_t)calibration.dig_P8) * p_acc) >> 19;
    p_acc = ((p_acc + var1 + var2) >> 8) + (((int64_t)calibration.dig_P7)<<4);
    return (float)p_acc / 256.0;
}

float BMP280::readFloatAltitudeMeters( void )
{
    float heightOutput = 0;
    heightOutput = ((float)-45846.2)*(pow(((float)readFloatPressure()/(float)101325), 0.190263) - (float)1);
    return heightOutput;
}

float BMP280::readFloatAltitudeFeet( void )
{
    float heightOutput = 0;
    heightOutput = readFloatAltitudeMeters() * 3.28084;
    return heightOutput;
}

float BMP280::readTempC( void )
{
    // Returns temperature in DegC, resolution is 0.01 DegC. Output value of “5123” equals 51.23 DegC.
    // t_fine carries fine temperature as global value
    //get the reading (adc_T);
    int32_t adc_T = ((uint32_t)readRegister(BMP280_TEMPERATURE_MSB_REG) << 12) | ((uint32_t)readRegister(BMP280_TEMPERATURE_LSB_REG) << 4) | ((readRegister(BMP280_TEMPERATURE_XLSB_REG) >> 4) & 0x0F);
    //By datasheet, calibrate
    int64_t var1, var2;
    var1 = ((((adc_T>>3) - ((int32_t)calibration.dig_T1<<1))) * ((int32_t)calibration.dig_T2)) >> 11;
    var2 = (((((adc_T>>4) - ((int32_t)calibration.dig_T1)) * ((adc_T>>4) - ((int32_t)calibration.dig_T1))) >> 12) *
            ((int32_t)calibration.dig_T3)) >> 14;
    t_fine = var1 + var2;
    float output = (t_fine * 5 + 128) >> 8;
    output = output / 100;
    return output;
}

float BMP280::readTempF( void )
{
    float output = readTempC();
    output = (output * 9) / 5 + 32;
    return output;
}

void BMP280::readRegisterRegion(uint8_t *outputPointer , uint8_t offset, uint8_t length)
{
    /*
    //define pointer that will point to the external space
    uint8_t i = 0;
    char c = 0;
    Wire.beginTransmission(settings.I2CAddress);
    Wire.write(offset);
    Wire.endTransmission();
    // request bytes from slave device
    Wire.requestFrom(settings.I2CAddress, length);
    while ( (Wire.available()) && (i < length))  // slave may send less than requested
    {
        c = Wire.read(); // receive a byte as character
        *outputPointer = c;
        outputPointer++;
        i++;
    }*/
    
    readBytes(settings.I2CAddress, offset, length, *outputPointer);
    
}

uint8_t BMP280::readRegister(uint8_t offset)
{
    /*uint8_t result;
    uint8_t numBytes = 1;
    Wire.beginTransmission(settings.I2CAddress);
    Wire.write(offset);
    Wire.endTransmission();
    Wire.requestFrom(settings.I2CAddress, numBytes);
    while ( Wire.available() ) // slave may send less than requested
    {
        result = Wire.read(); // receive a byte as a proper uint8_t
    }*/
    uint8_t buffer[1];
    readByte(settings.I2CAddress, offset, buffer);
    return buffer[0];
}

int16_t BMP280::readRegisterInt16( uint8_t offset )
{
    uint8_t myBuffer[2];
    readRegisterRegion(myBuffer, offset, 2);  //Does memory transfer
    int16_t output = (int16_t)myBuffer[0] | int16_t(myBuffer[1] << 8);
    return output;
}

void BMP280::writeRegister(uint8_t offset, uint8_t dataToWrite)
{
    /*Wire.beginTransmission(settings.I2CAddress);
    Wire.write(offset);
    Wire.write(dataToWrite);
    Wire.endTransmission();*/
    writeByte(settings.I2CAddress, offset, dataToWrite);
}
