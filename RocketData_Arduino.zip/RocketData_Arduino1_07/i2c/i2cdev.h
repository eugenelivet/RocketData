/*************************************************************************************************/
/* ne pas oublier d'ajouter la bibliothèque I2C.h modifiée (envoi de mots de 16 bits)            */
/*************************************************************************************************/
#define I2CDEV_DEFAULT_READ_TIMEOUT     5
uint16_t readTimeout = I2CDEV_DEFAULT_READ_TIMEOUT;

#define BUFFER_LENGTH 32

int8_t readBit(uint8_t devAddr, uint8_t regAddr, uint8_t bitNum, uint8_t *data, uint16_t timeout=readTimeout);
int8_t readBitW(uint8_t devAddr, uint8_t regAddr, uint8_t bitNum, uint16_t *data, uint16_t timeout=readTimeout);
int8_t readBits(uint8_t devAddr, uint8_t regAddr, uint8_t bitStart, uint8_t length, uint8_t *data, uint16_t timeout=readTimeout);
int8_t readBitsW(uint8_t devAddr, uint8_t regAddr, uint8_t bitStart, uint8_t length, uint16_t *data, uint16_t timeout=readTimeout);
int8_t readByte(uint8_t devAddr, uint8_t regAddr, uint8_t *data, uint16_t timeout=readTimeout);
int8_t readWord(uint8_t devAddr, uint8_t regAddr, uint16_t *data, uint16_t timeout=readTimeout);
int8_t readBytes(uint8_t devAddr, uint8_t regAddr, uint8_t length, uint8_t *data, uint16_t timeout=readTimeout);
int8_t readWords(uint8_t devAddr, uint8_t regAddr, uint8_t length, uint16_t *data, uint16_t timeout=readTimeout);

bool writeBit(uint8_t devAddr, uint8_t regAddr, uint8_t bitNum, uint8_t data);
bool writeBitW(uint8_t devAddr, uint8_t regAddr, uint8_t bitNum, uint16_t data);
bool writeBits(uint8_t devAddr, uint8_t regAddr, uint8_t bitStart, uint8_t length, uint8_t data);
bool writeBitsW(uint8_t devAddr, uint8_t regAddr, uint8_t bitStart, uint8_t length, uint16_t data);
bool writeByte(uint8_t devAddr, uint8_t regAddr, uint8_t data);
bool writeWord(uint8_t devAddr, uint8_t regAddr, uint16_t data);
bool writeBytes(uint8_t devAddr, uint8_t regAddr, uint8_t length, uint8_t *data);
bool writeWords(uint8_t devAddr, uint8_t regAddr, uint8_t length, uint16_t *data);

void initI2C()
{
  I2c.begin();
  I2c.timeOut(5);  
  TWBR = 6;
}

int8_t readBytes(uint8_t devAddr, uint8_t regAddr, uint8_t length, uint8_t *data, uint16_t timeout) 
{
    int8_t count = 0;
    uint32_t t1 = millis();
    for (uint8_t k = 0; k < length; k += min(length, BUFFER_LENGTH)) {
      I2c.read(devAddr,regAddr,(uint8_t)min(length - k, BUFFER_LENGTH));
      for (; I2c.available() && (timeout == 0 || millis() - t1 < timeout); count++) {
        data[count] = I2c.receive();
      }
    }
    return count;
}

int8_t readByte(uint8_t devAddr, uint8_t regAddr, uint8_t *data, uint16_t timeout) 
{
    return readBytes(devAddr, regAddr, 1, data, timeout);
}

int8_t readBit(uint8_t devAddr, uint8_t regAddr, uint8_t bitNum, uint8_t *data, uint16_t timeout) 
{
    uint8_t b;
    uint8_t count = readByte(devAddr, regAddr, &b, timeout);
    *data = b & (1 << bitNum);
    return count;
}

int8_t readBits(uint8_t devAddr, uint8_t regAddr, uint8_t bitStart, uint8_t length, uint8_t *data, uint16_t timeout) 
{
    // 01101001 read byte
    // 76543210 bit numbers
    //    xxx   args: bitStart=4, length=3
    //    010   masked
    //   -> 010 shifted
    uint8_t count, b;
    if ((count = readByte(devAddr, regAddr, &b, timeout)) != 0) {
        uint8_t mask = ((1 << length) - 1) << (bitStart - length + 1);
        b &= mask;
        b >>= (bitStart - length + 1);
        *data = b;
    }
    return count;
}

bool writeBit(uint8_t devAddr, uint8_t regAddr, uint8_t bitNum, uint8_t data) 
{
    uint8_t b;
    readByte(devAddr, regAddr, &b, 1000);
    b = (data != 0) ? (b | (1 << bitNum)) : (b & ~(1 << bitNum));
    return writeByte(devAddr, regAddr, b);
}

bool writeBits(uint8_t devAddr, uint8_t regAddr, uint8_t bitStart, uint8_t length, uint8_t data) 
{
    //      010 value to write
    // 76543210 bit numbers
    //    xxx   args: bitStart=4, length=3
    // 00011100 mask byte
    // 10101111 original value (sample)
    // 10100011 original & ~mask
    // 10101011 masked | value
    uint8_t b;
    if (readByte(devAddr, regAddr, &b, 1000) != 0) {
        uint8_t mask = ((1 << length) - 1) << (bitStart - length + 1);
        data <<= (bitStart - length + 1); // shift data into correct position
        data &= mask; // zero all non-important bits in data
        b &= ~(mask); // zero all important bits in existing byte
        b |= data; // combine data with existing byte
        return writeByte(devAddr, regAddr, b);
    } else {
        return false;
    }
}

bool writeBytes(uint8_t devAddr, uint8_t regAddr, uint8_t length, uint8_t* data) {
    uint8_t status = 0;
    status = I2c.write(devAddr,(uint8_t) regAddr,data,length);
    return status == 0;
}

bool writeByte(uint8_t devAddr, uint8_t regAddr, uint8_t data) 
{
    return writeBytes(devAddr, regAddr, 1, &data);
}

bool writeWords(uint8_t devAddr, uint8_t regAddr, uint8_t length, uint16_t* data) {
    uint8_t status = 0;
    I2c.write(devAddr,(uint8_t) regAddr,data,length);
    return status == 0;
}

bool writeWord(uint8_t devAddr, uint8_t regAddr, uint16_t data) {
    return writeWords(devAddr, regAddr, 1, &data);
}
