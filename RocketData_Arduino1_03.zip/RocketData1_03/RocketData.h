#include "spieeprom/spieeprom.cpp"
#include "i2c/i2c.h"
#include "i2c/i2c.cpp"
#include "i2c/i2cdev.h"

#define LED   4
#define BTLED 12
#define INTMPU 7

#define localPressure   1010.0  // hPa
#define timeTransfer    5       // *10ms
#define loopTime        9970    // us

SPIEEPROM eeprom;

bool mpuInterrupt = false;
bool startRecord = false;
bool startSend = false;
bool BTconnected = false;
bool armed = false;

struct
{
  float sensor[2];
}data;

int tickDebug = 0;
int tickBT = 0;
int tickSample = 0;
int tickTransfer = 0;
long loopEndTime = loopTime;
long loopStartTime = 0;
long timeSampleStart = 0;
long timeSampleEnd = 0;
long timeStamp = 0;

String rxData = "";
String txData = "";

long address = 0;
int numSample = 0;

float angleX, angleY, angleZ;
float accX, accY, accZ;
//float tempMPU;
//float pression, tempBMP;
float alt, altFiltered, altInit;
